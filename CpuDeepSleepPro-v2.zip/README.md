# CPU & Sleep Pro (Root + Shizuku)

## GitHub Actions se APK Kaise Banayein:
1. Is ZIP ko extract karein ya seedha GitHub repo mein upload karein.
2. Repo mein `.github/workflows/build_apk.yml` file honi chahiye.
3. GitHub repo ke **Actions** tab mein jayein -> **Build Android Debug APK** par click karein -> **Run workflow** dabayein (ya koi bhi commit push karein).
4. Build complete hone ke baad niche **Artifacts** se `CpuDeepSleepPro-APK` download karke install karein.
