package com.abhishek.cpumaster

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader

object ShellExecutor {

    enum class Mode { ROOT, SHIZUKU, NONE }

    fun getAvailableMode(): Mode {
        if (isRootAvailable()) return Mode.ROOT
        if (isShizukuAvailable()) return Mode.SHIZUKU
        return Mode.NONE
    }

    private fun isRootAvailable(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val exitCode = process.waitFor()
            exitCode == 0
        } catch (e: Exception) {
            false
        }
    }

    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    fun runCommand(cmd: String): String {
        return when (getAvailableMode()) {
            Mode.ROOT -> executeRoot(cmd)
            Mode.SHIZUKU -> executeShizuku(cmd)
            Mode.NONE -> "Error: No Root or Shizuku permission"
        }
    }

    private fun executeRoot(cmd: String): String {
        return try {
            val process = Runtime.getRuntime().exec("su")
            val os = DataOutputStream(process.outputStream)
            os.writeBytes("$cmd\n")
            os.writeBytes("exit\n")
            os.flush()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText().trim()
            process.waitFor()
            output
        } catch (e: Exception) {
            "Root Error: ${e.message}"
        }
    }

    private fun executeShizuku(cmd: String): String {
        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText().trim()
            process.waitFor()
            output
        } catch (e: Exception) {
            "Shizuku Error: ${e.message}"
        }
    }

    fun getCpuInfo(): Pair<Long, Long> {
        val maxStr = runCommand("cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq")
        val minStr = runCommand("cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq")
        val max = maxStr.toLongOrNull() ?: 2400000L
        val min = minStr.toLongOrNull() ?: 300000L
        return Pair(min, max)
    }

    fun getCurrentScalingMax(): Long {
        val cur = runCommand("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq")
        return cur.toLongOrNull() ?: getCpuInfo().second
    }

    fun backupDefaultsIfNeeded(context: Context) {
        val prefs = context.getSharedPreferences("cpu_backup", Context.MODE_PRIVATE)
        if (!prefs.contains("default_max")) {
            val (min, max) = getCpuInfo()
            val curMax = getCurrentScalingMax()
            prefs.edit()
                .putLong("default_min", min)
                .putLong("default_max", if (curMax > 0) curMax else max)
                .apply()
        }
    }

    fun setCpuMaxFrequency(freqKHz: Long): String {
        val coreCount = Runtime.getRuntime().availableProcessors()
        val sb = StringBuilder()
        for (i in 0 until coreCount) {
            val path = "/sys/devices/system/cpu/cpu$i/cpufreq/scaling_max_freq"
            sb.append("chmod 644 $path && echo $freqKHz > $path; ")
        }
        return runCommand(sb.toString())
    }

    fun resetCpuToBackup(context: Context): Long {
        val prefs = context.getSharedPreferences("cpu_backup", Context.MODE_PRIVATE)
        val savedMax = prefs.getLong("default_max", getCpuInfo().second)
        setCpuMaxFrequency(savedMax)
        return savedMax
    }

    fun enableUltraDeepSleep() {
        val commands = """
            dumpsys deviceidle force-idle
            cmd netpolicy set restrict-background true
            settings put global low_power 1
            am kill-all
        """.trimIndent()
        runCommand(commands)
    }

    fun disableUltraDeepSleep() {
        val commands = """
            dumpsys deviceidle unforce
            cmd netpolicy set restrict-background false
            settings put global low_power 0
        """.trimIndent()
        runCommand(commands)
    }
}
