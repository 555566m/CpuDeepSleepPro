package com.abhishek.cpumaster

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private val screenReceiver = SleepReceiver()
    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Shizuku Permission Granted!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenReceiver, filter)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF4ADE80),
                secondary = Color(0xFF38BDF8),
                surface = Color(0xFF1E293B),
                background = Color(0xFF0F172A)
            )) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    CpuSleepDashboard()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        unregisterReceiver(screenReceiver)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CpuSleepDashboard() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("cpu_backup", Context.MODE_PRIVATE) }

    var mode by remember { mutableStateOf(ShellExecutor.getAvailableMode()) }
    var minFreq by remember { mutableStateOf(300000L) }
    var maxFreq by remember { mutableStateOf(2400000L) }
    var backupFreq by remember { mutableStateOf(2400000L) }
    var sliderFreq by remember { mutableFloatStateOf(2400000f) }

    val timeOptions = listOf(10, 15, 20, 30, 60, 120, 180)
    val timeLabels = listOf("10 Min", "15 Min", "20 Min", "30 Min", "1 Hour", "2 Hours", "3 Hours")

    var isSleepEnabled by remember { mutableStateOf(prefs.getBoolean("sleep_enabled", false)) }
    var selectedTimeIndex by remember {
        val savedMins = prefs.getInt("sleep_delay_mins", 10)
        val idx = timeOptions.indexOf(savedMins).coerceAtLeast(0)
        mutableIntStateOf(idx)
    }
    var showTipsDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        mode = ShellExecutor.getAvailableMode()
        if (mode != ShellExecutor.Mode.NONE) {
            ShellExecutor.backupDefaultsIfNeeded(context)
            val (min, max) = ShellExecutor.getCpuInfo()
            minFreq = min
            maxFreq = max
            backupFreq = prefs.getLong("default_max", max)
            sliderFreq = ShellExecutor.getCurrentScalingMax().toFloat().coerceIn(min.toFloat(), max.toFloat())
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("CPU & Sleep Pro", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text(
                            text = when (mode) {
                                ShellExecutor.Mode.ROOT -> "● Root Mode Active"
                                ShellExecutor.Mode.SHIZUKU -> "● Shizuku Mode Active"
                                ShellExecutor.Mode.NONE -> "● Permission Required"
                            },
                            fontSize = 12.sp,
                            color = if (mode == ShellExecutor.Mode.NONE) Color(0xFFF87171) else Color(0xFF4ADE80)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showTipsDialog = true }) {
                        Icon(Icons.Rounded.HelpOutline, contentDescription = "Tips", tint = Color(0xFF38BDF8))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (mode == ShellExecutor.Mode.NONE) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Root ya Shizuku Connect Karein", fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "CPU frequency control karne ke liye Root grant karein ya Shizuku app start karke niche button dabayein.",
                            fontSize = 13.sp, color = Color(0xFFFECACA)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                if (Shizuku.pingBinder()) {
                                    Shizuku.requestPermission(100)
                                } else {
                                    Toast.makeText(context, "Pehle Shizuku App chalu karein!", Toast.LENGTH_SHORT).show()
                                }
                                mode = ShellExecutor.getAvailableMode()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                        ) {
                            Text("Grant Shizuku / Refresh")
                        }
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Speed, contentDescription = null, tint = Color(0xFF4ADE80))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("CPU Max Frequency", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = "${(sliderFreq / 1000).roundToInt()} MHz",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF4ADE80)
                        )
                        Text(
                            text = "Backup: ${backupFreq / 1000} MHz",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Slider(
                        value = sliderFreq,
                        onValueChange = { sliderFreq = it },
                        valueRange = minFreq.toFloat()..maxFreq.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF4ADE80),
                            activeTrackColor = Color(0xFF4ADE80),
                            inactiveTrackColor = Color(0xFF334155)
                        )
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${minFreq / 1000} MHz", fontSize = 11.sp, color = Color.Gray)
                        Text("Swipe to Adjust", fontSize = 11.sp, color = Color(0xFF38BDF8))
                        Text("${maxFreq / 1000} MHz", fontSize = 11.sp, color = Color.Gray)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                ShellExecutor.setCpuMaxFrequency(sliderFreq.toLong())
                                Toast.makeText(context, "CPU Set to ${(sliderFreq / 1000).roundToInt()} MHz", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4ADE80), contentColor = Color.Black)
                        ) {
                            Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Apply", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                val restored = ShellExecutor.resetCpuToBackup(context)
                                sliderFreq = restored.toFloat()
                                Toast.makeText(context, "Reset to Backup (${restored / 1000} MHz)", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFF38BDF8))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Reset Backup", color = Color(0xFF38BDF8))
                        }
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Bedtime, contentDescription = null, tint = Color(0xFF38BDF8))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Ultra Deep Sleep", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color.White)
                        }
                        Switch(
                            checked = isSleepEnabled,
                            onCheckedChange = {
                                isSleepEnabled = it
                                prefs.edit().putBoolean("sleep_enabled", it).apply()
                                Toast.makeText(context, if (it) "Auto Deep Sleep ON" else "Auto Deep Sleep OFF", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Screen off hone ke set time baad phone Deep Sleep mein chala jayega. Background data/apps freeze honge — sirf Calls aur SMS aayenge.",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Screen Off Delay:", fontSize = 14.sp, color = Color.White)
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = timeLabels[selectedTimeIndex],
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Slider(
                        value = selectedTimeIndex.toFloat(),
                        onValueChange = {
                            selectedTimeIndex = it.roundToInt()
                            val mins = timeOptions[selectedTimeIndex]
                            prefs.edit().putInt("sleep_delay_mins", mins).apply()
                        },
                        valueRange = 0f..(timeOptions.size - 1).toFloat(),
                        steps = timeOptions.size - 2,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF38BDF8),
                            activeTrackColor = Color(0xFF38BDF8),
                            inactiveTrackColor = Color(0xFF334155)
                        )
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("10m", fontSize = 11.sp, color = Color.Gray)
                        Text("30m", fontSize = 11.sp, color = Color.Gray)
                        Text("1h", fontSize = 11.sp, color = Color.Gray)
                        Text("3h", fontSize = 11.sp, color = Color.Gray)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            ShellExecutor.enableUltraDeepSleep()
                            Toast.makeText(context, "Deep Sleep Activated Now!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                    ) {
                        Icon(Icons.Rounded.BatterySaver, contentDescription = null, tint = Color(0xFF4ADE80))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Test Deep Sleep Now", color = Color.White)
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Lightbulb, contentDescription = null, tint = Color(0xFFFACC15))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Pro Tips & Usage Guide", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• Swipe Sliders: Upar diye sliders ko left/right swipe karke CPU speed ya Deep Sleep time set karein.", fontSize = 12.sp, color = Color(0xFFCBD5E1))
                    Text("• Backup Safe: App khulte hi default CPU frequency save ho jati hai. 'Reset Backup' dabate hi phone factory speed par aa jayega.", fontSize = 12.sp, color = Color(0xFFCBD5E1))
                    Text("• Shizuku Users: Non-root phone mein Shizuku start karein; CPU frequency kernel lock ke karan kuch phones mein sirf Root par change hoti hai, par Deep Sleep dono par kaam karega.", fontSize = 12.sp, color = Color(0xFFCBD5E1))
                }
            }
        }

        if (showTipsDialog) {
            AlertDialog(
                onDismissRequest = { showTipsDialog = false },
                title = { Text("Kaise Use Karein?") },
                text = {
                    Text(
                        "1. Root / Shizuku: Agar phone Root hai toh seedha Allow karein. Non-Root hai toh Play Store se Shizuku install karke Wireless Debugging se start karein.\n\n" +
                        "2. Battery Saving: Night mein '10 Min' ya '15 Min' set karke Ultra Deep Sleep ON chhod dein. Screen off hote hi background internet aur apps freeze ho jayenge, sirf SIM Calls aur SMS aayenge.\n\n" +
                        "3. CPU Reset: Gaming ke baad ya battery bachane ke baad 'Reset Backup' dabayein taaki original frequency wapas set ho jaye."
                    )
                },
                confirmButton = {
                    TextButton(onClick = { showTipsDialog = false }) { Text("Samajh Gaya") }
                }
            )
        }
    }
}
