package com.abhishek.cpumaster

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class SleepReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("cpu_backup", Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean("sleep_enabled", false)
        val mins = prefs.getInt("sleep_delay_mins", 10)
        when (intent.action) {
            Intent.ACTION_SCREEN_OFF -> if (enabled) scheduleDeepSleep(context, mins)
            Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                cancelDeepSleep(context)
                Thread { ShellExecutor.disableUltraDeepSleep() }.start()
            }
            "ACTION_TRIGGER_DEEP_SLEEP" -> Thread { ShellExecutor.enableUltraDeepSleep() }.start()
        }
    }

    companion object {
        fun scheduleDeepSleep(context: Context, minutes: Int) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                context, 101, Intent(context, SleepReceiver::class.java).apply { action = "ACTION_TRIGGER_DEEP_SLEEP" },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val trigger = System.currentTimeMillis() + (minutes * 60 * 1000L)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            }
        }

        fun cancelDeepSleep(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                context, 101, Intent(context, SleepReceiver::class.java).apply { action = "ACTION_TRIGGER_DEEP_SLEEP" },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.cancel(pi)
        }
    }
}
