package com.abhishek.cpumaster

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val screenReceiver = SleepReceiver()
    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, res ->
        if (res == PackageManager.PERMISSION_GRANTED) Toast.makeText(this, "Shizuku Connected!", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(shizukuListener)
        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        })
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF4ADE80), secondary = Color(0xFF38BDF8),
                surface = Color(0xFF1E293B), background = Color(0xFF0F172A)
            )) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { CpuSleepDashboard() }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuListener)
        unregisterReceiver(screenReceiver)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CpuSleepDashboard() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("cpu_backup", Context.MODE_PRIVATE) }
    var mode by remember { mutableStateOf(ShellExecutor.getAvailableMode()) }
    var minFreq by remember { mutableStateOf(300000L) }
    var maxFreq by remember { mutableStateOf(2400000L) }
    var backupFreq by remember { mutableStateOf(2400000L) }
    var sliderFreq by remember { mutableFloatStateOf(2400000f) }

    val timeOptions = listOf(10, 15, 20, 30, 60, 120, 180)
    val timeLabels = listOf("10 Min", "15 Min", "20 Min", "30 Min", "1 Hour", "2 Hours", "3 Hours")
    var isSleepEnabled by remember { mutableStateOf(prefs.getBoolean("sleep_enabled", false)) }
    var selectedTimeIndex by remember { mutableIntStateOf(timeOptions.indexOf(prefs.getInt("sleep_delay_mins", 10)).coerceAtLeast(0)) }
    var showTips by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        mode = ShellExecutor.getAvailableMode()
        if (mode != ShellExecutor.Mode.NONE) {
            ShellExecutor.backupDefaultsIfNeeded(context)
            val (min, max) = ShellExecutor.getCpuInfo()
            minFreq = min; maxFreq = max
            backupFreq = prefs.getLong("default_max", max)
            sliderFreq = ShellExecutor.getCurrentScalingMax().toFloat().coerceIn(min.toFloat(), max.toFloat())
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = {
                Column {
                    Text("CPU & Sleep Pro", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text(
                        when (mode) {
                            ShellExecutor.Mode.ROOT -> "● Root Active"
                            ShellExecutor.Mode.SHIZUKU -> "● Shizuku Active"
                            ShellExecutor.Mode.NONE -> "● Permission Needed"
                        },
                        fontSize = 12.sp,
                        color = if (mode == ShellExecutor.Mode.NONE) Color(0xFFF87171) else Color(0xFF4ADE80)
                    )
                }
            },
            actions = { IconButton(onClick = { showTips = true }) { Icon(Icons.Rounded.HelpOutline, null, tint = Color(0xFF38BDF8)) } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
        )
    }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (mode == ShellExecutor.Mode.NONE) {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D)), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Root ya Shizuku Connect Karein", fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = {
                            if (Shizuku.pingBinder()) Shizuku.requestPermission(100)
                            else Toast.makeText(context, "Pehle Shizuku App chalu karein!", Toast.LENGTH_SHORT).show()
                            mode = ShellExecutor.getAvailableMode()
                        }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
                            Text("Grant Shizuku / Refresh")
                        }
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Speed, null, tint = Color(0xFF4ADE80))
                        Spacer(Modifier.width(8.dp))
                        Text("CPU Max Frequency", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color.White)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                        Text("${(sliderFreq / 1000).roundToInt()} MHz", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF4ADE80))
                        Text("Backup: ${backupFreq / 1000} MHz", fontSize = 12.sp, color = Color(0xFF94A3B8))
                    }
                    Slider(value = sliderFreq, onValueChange = { sliderFreq = it }, valueRange = minFreq.toFloat()..maxFreq.toFloat())
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(onClick = {
                            ShellExecutor.setCpuMaxFrequency(sliderFreq.toLong())
                            Toast.makeText(context, "Applied ${(sliderFreq / 1000).roundToInt()} MHz", Toast.LENGTH_SHORT).show()
                        }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4ADE80), contentColor = Color.Black)) {
                            Text("Apply", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(onClick = {
                            val r = ShellExecutor.resetCpuToBackup(context)
                            sliderFreq = r.toFloat()
                            Toast.makeText(context, "Reset: ${r / 1000} MHz", Toast.LENGTH_SHORT).show()
                        }, modifier = Modifier.weight(1f)) {
                            Text("Reset Backup", color = Color(0xFF38BDF8))
                        }
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Bedtime, null, tint = Color(0xFF38BDF8))
                            Spacer(Modifier.width(8.dp))
                            Text("Ultra Deep Sleep", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color.White)
                        }
                        Switch(checked = isSleepEnabled, onCheckedChange = {
                            isSleepEnabled = it
                            prefs.edit().putBoolean("sleep_enabled", it).apply()
                        })
                    }
                    Text("Screen off ke baad set time par Deep Sleep (Only Calls & SMS).", fontSize = 12.sp, color = Color(0xFF94A3B8))
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Delay:", color = Color.White)
                        Box(Modifier.background(Color(0xFF0F172A), RoundedCornerShape(8.dp)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                            Text(timeLabels[selectedTimeIndex], fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                        }
                    }
                    Slider(
                        value = selectedTimeIndex.toFloat(),
                        onValueChange = {
                            selectedTimeIndex = it.roundToInt()
                            prefs.edit().putInt("sleep_delay_mins", timeOptions[selectedTimeIndex]).apply()
                        },
                        valueRange = 0f..(timeOptions.size - 1).toFloat(),
                        steps = timeOptions.size - 2
                    )
                    Button(onClick = {
                        ShellExecutor.enableUltraDeepSleep()
                        Toast.makeText(context, "Deep Sleep Active!", Toast.LENGTH_SHORT).show()
                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))) {
                        Text("Test Deep Sleep Now", color = Color.White)
                    }
                }
            }
        }
        if (showTips) {
            AlertDialog(onDismissRequest = { showTips = false }, title = { Text("Tips") },
                text = { Text("1. Root ya Shizuku connect karein.\n2. Slider swipe karke CPU freq ya Deep Sleep time (10m-3h) set karein.\n3. Reset Backup se original CPU speed wapas aayegi.") },
                confirmButton = { TextButton(onClick = { showTips = false }) { Text("OK") } }
            )
        }
    }
}
