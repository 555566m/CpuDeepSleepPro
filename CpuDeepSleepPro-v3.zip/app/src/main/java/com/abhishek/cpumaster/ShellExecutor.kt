package com.abhishek.cpumaster

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader

object ShellExecutor {
    enum class Mode { ROOT, SHIZUKU, NONE }

    fun getAvailableMode(): Mode {
        if (isRootAvailable()) return Mode.ROOT
        if (isShizukuAvailable()) return Mode.SHIZUKU
        return Mode.NONE
    }

    private fun isRootAvailable(): Boolean = try {
        Runtime.getRuntime().exec(arrayOf("su", "-c", "id")).waitFor() == 0
    } catch (e: Exception) { false }

    fun isShizukuAvailable(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) { false }

    fun runCommand(cmd: String): String = when (getAvailableMode()) {
        Mode.ROOT -> executeRoot(cmd)
        Mode.SHIZUKU -> executeShizuku(cmd)
        Mode.NONE -> "No Permission"
    }

    private fun executeRoot(cmd: String): String = try {
        val p = Runtime.getRuntime().exec("su")
        val os = DataOutputStream(p.outputStream)
        os.writeBytes("$cmd\nexit\n")
        os.flush()
        val out = BufferedReader(InputStreamReader(p.inputStream)).readText().trim()
        p.waitFor()
        out
    } catch (e: Exception) { e.message ?: "" }

    private fun executeShizuku(cmd: String): String = try {
        val p = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
        val out = BufferedReader(InputStreamReader(p.inputStream)).readText().trim()
        p.waitFor()
        out
    } catch (e: Exception) { e.message ?: "" }

    fun getCpuInfo(): Pair<Long, Long> {
        val max = runCommand("cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq").toLongOrNull() ?: 2400000L
        val min = runCommand("cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq").toLongOrNull() ?: 300000L
        return Pair(min, max)
    }

    fun getCurrentScalingMax(): Long =
        runCommand("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq").toLongOrNull() ?: getCpuInfo().second

    fun backupDefaultsIfNeeded(context: Context) {
        val prefs = context.getSharedPreferences("cpu_backup", Context.MODE_PRIVATE)
        if (!prefs.contains("default_max")) {
            val (min, max) = getCpuInfo()
            val cur = getCurrentScalingMax()
            prefs.edit().putLong("default_min", min).putLong("default_max", if (cur > 0) cur else max).apply()
        }
    }

    fun setCpuMaxFrequency(freqKHz: Long): String {
        val cores = Runtime.getRuntime().availableProcessors()
        val sb = StringBuilder()
        for (i in 0 until cores) {
            val path = "/sys/devices/system/cpu/cpu$i/cpufreq/scaling_max_freq"
            sb.append("chmod 644 $path && echo $freqKHz > $path; ")
        }
        return runCommand(sb.toString())
    }

    fun resetCpuToBackup(context: Context): Long {
        val prefs = context.getSharedPreferences("cpu_backup", Context.MODE_PRIVATE)
        val savedMax = prefs.getLong("default_max", getCpuInfo().second)
        setCpuMaxFrequency(savedMax)
        return savedMax
    }

    fun enableUltraDeepSleep() {
        runCommand("dumpsys deviceidle force-idle; cmd netpolicy set restrict-background true; settings put global low_power 1; am kill-all")
    }

    fun disableUltraDeepSleep() {
        runCommand("dumpsys deviceidle unforce; cmd netpolicy set restrict-background false; settings put global low_power 0")
    }
}
